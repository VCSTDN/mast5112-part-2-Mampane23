import { createStackNavigator } from "@react-navigation/stack";
import MainContainer from './MainContainer';

const Stack = createStackNavigator();

function App(){
  return (
    <MainContainer/>
  )
}

export default App;